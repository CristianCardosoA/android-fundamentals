package com.example.intentparcelable;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText nombre,paterno,materno,edad;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nombre=findViewById(R.id.txname);
        paterno=findViewById(R.id.txape);
        materno=findViewById(R.id.txmate);
        edad=findViewById(R.id.txedad);
        button=findViewById(R.id.btn);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(MainActivity.this,MainDetalle.class);
                int edade = Integer.parseInt(String.valueOf(edad.getText()));
                Alumno alumno= new Alumno(
                    nombre.getText().toString(),
                        paterno.getText().toString(),
                        materno.getText().toString(),
                        edade
                );
                intent.putExtra("LlaveKey",alumno);
                startActivity(intent);
            }
        });
    }
}