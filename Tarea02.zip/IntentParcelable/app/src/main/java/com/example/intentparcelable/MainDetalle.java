package com.example.intentparcelable;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainDetalle extends AppCompatActivity {
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_detalle);
        textView=findViewById(R.id.tvdetalle);
        Bundle bundle = getIntent().getExtras();

        Alumno alumno = bundle.getParcelable("LlaveKey");

        if(alumno != null){
            textView.setText(String.format("%s \n %s \n%s \n%s \n",
                    alumno.getNombre(),alumno.getPaterno(),alumno.getMaterno(),alumno.getEdad()));
        }

    }
}