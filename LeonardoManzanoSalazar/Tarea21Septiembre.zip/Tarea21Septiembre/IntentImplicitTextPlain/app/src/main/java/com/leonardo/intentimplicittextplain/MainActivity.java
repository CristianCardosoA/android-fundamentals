package com.leonardo.intentimplicittextplain;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView textView1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView1=findViewById(R.id.editText);
    }
    public void shareText(View view){
        String txt = textView1.getText().toString();
        Intent intento = new Intent();
        intento.setAction(Intent.ACTION_SEND);
        intento.putExtra(Intent.EXTRA_TEXT,txt);
        intento.setType("text/plain");
        if(intento.resolveActivity(getPackageManager()) != null){
            startActivity(intento);
        }
    }
}
