package com.leonardo.receiverplaintext;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView textView1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intento = getIntent();
        String txt = intento.getStringExtra(Intent.EXTRA_TEXT);
        if(txt != null){
            textView1 = findViewById(R.id.textView1);
            System.out.println("la cadena es: "+txt);
            textView1.setText(txt);
        }
    }
}
