package com.leonardo.parcelable;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class RecibiendoObjeto extends AppCompatActivity {
    TextView txt1, txt2, txt3, txt4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recibiendo_objeto);
        txt1=findViewById(R.id.textView2);
        txt2=findViewById(R.id.textView7);
        txt3=findViewById(R.id.textView8);
        txt4= findViewById(R.id.textView9);
        Alumno alumno1=new Alumno();
        Intent intento = getIntent();
        alumno1=intento.getParcelableExtra(MainActivity.EXTRA);
        txt1.setText("Nombre: "+alumno1.getNombre());
        txt2.setText("Apellido Paterno: "+alumno1.getApPaterno());
        txt3.setText("Apellido Materno: "+alumno1.getApMaterno());
        txt4.setText("Edad: "+alumno1.getEdad());
    }
}
